# JAY TV u FKRS Android TV launcher project

This is the Android Studio project source for a fullscreen WebView launcher prototype. It includes the custom home screen, live clock, remote-key navigation and shortcuts. It is not a compiled APK yet.

## Build the APK
1. Install Android Studio on a computer and open this folder (`jay_tv_android`).
2. Let Android Studio sync the Gradle project and install any requested Android SDK platform (API 35).
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The APK will be in `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy it to your Google TV and install it. You may need to enable installation from the file manager you use.

## Notes
- The app declares HOME and LEANBACK_LAUNCHER intent categories so Android TV can offer it as a home app. Some Google TV models restrict replacing the default launcher; this app cannot bypass those system restrictions.
- App tiles currently open their service website in an external handler/browser. They do not yet launch installed native apps directly. This is a prototype, and service availability may depend on region and login.
- To build on a computer, use a current Android Studio installation with JDK 17 and Android SDK platform 35.
